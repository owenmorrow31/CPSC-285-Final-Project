﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Assigment11_V1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            ClientName.Text = string.Empty;
            Gender.Text = string.Empty;
            Age.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
            String sqlQuery = "INSERT INTO Client(ClientName,Gender,Age) VALUES ('"+ClientName.Text+"','"+Gender.Text+"',"+int.Parse(Age.Text)+");";
            
            try
            {
               // MessageBox.Show(sqlQuery);
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                MessageBox.Show("Client was Successfully added");
               
                rdr.Close();
                cnn.Close();
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
    }
}
