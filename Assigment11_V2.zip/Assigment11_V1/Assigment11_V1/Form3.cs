﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Assigment11_V1
{
    
    public partial class Form3 : Form
    {
        public static List<int> Ids = new List<int>();
        public static Dictionary<int, string> conversion = new Dictionary<int, string> { { 8, "8am" }, { 9, "9am" }, { 10, "10am" }, { 11, "11am" }, { 12, "12pm" }, { 13, "1pm" }, { 14, "2pm" }, { 15, "3pm" } };
        public Form3()
        {
            InitializeComponent();
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
            String sqlQuery = "Select id,Staffname from staff where position ='instructor'";
            
           
            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Ids.Add(rdr.GetInt32(0));
                        comboBox1.Items.Add(rdr[1]);
                        
                       

                    }
                }
                else
                {
                    MessageBox.Show("No data read in");
                }
                rdr.Close();
                cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void clientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.assigment11DataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
            try { 
            this.staffTableAdapter.Fill(this.assigment11DataSet.Staff);

            this.clientTableAdapter.Fill(this.assigment11DataSet.Client);
        }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            List<int>shedule= new List<int>(); 
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
            String sqlQuery = "Select classtime from classroom where staffid =" + Ids[comboBox1.SelectedIndex]+"and classdate='"+dateTimePicker1.Value.ToString("yyyy/MM/dd")+"'";
          //  MessageBox.Show(sqlQuery);

            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        shedule.Add(rdr.GetInt32(0));
     
                    }
                }
                else
                {
                    MessageBox.Show("No data to read in");
                   
                }
                rdr.Close();
                cnn.Close();
                foreach(var item in conversion)
                {
                    if (!shedule.Contains(item.Key))
                    {
                        comboBox2.Items.Add(item.Value);
                    }
                }
                if(comboBox2.Items.Count==0)//conversion.Count== shedule.Count
                {
                    MessageBox.Show("No avalible time for "+comboBox1.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value.DayOfWeek == DayOfWeek.Saturday || dateTimePicker1.Value.DayOfWeek == DayOfWeek.Sunday)
            {
                MessageBox.Show("Weekdays Only Please");

            }else if (dateTimePicker1.Value <DateTime.Now.Date)
            {
                   
                MessageBox.Show("Please choose a date thats not prior");
            }
            else if(comboBox1.Text !=string.Empty &&comboBox2.Text!=string.Empty&&comboBox2.Items.Count!=0)
            {
                
              // MessageBox.Show( conversion.FirstOrDefault(x => x.Value == comboBox2.Text).Key.ToString());
                string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
                SqlConnection cnn;
                SqlCommand cmd;
                SqlDataReader rdr;
                String sqlQuery = "INSERT INTO Classroom(Classdate,Classtime,staffID,ClientID) VALUES('"+dateTimePicker1.Value.ToString("yyyy/MM/dd")+"',"+ conversion.FirstOrDefault(x => x.Value == comboBox2.Text).Key+","+Ids[comboBox1.SelectedIndex]+","+int.Parse(idTextBox.Text)+");";
             

                try
                {
               //     MessageBox.Show(sqlQuery);
                    cnn = new SqlConnection(connectionString);
                    cnn.Open();
                    cmd = new SqlCommand(sqlQuery, cnn);
                    rdr = cmd.ExecuteReader();
                    MessageBox.Show("Class was Successfully added");
                    
                    rdr.Close();
                    cnn.Close();
                  comboBox2.Items.RemoveAt(comboBox2.SelectedIndex);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                  

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    
                }
            }
            else
            {
                MessageBox.Show("Please Choose a Instructor and Time ");
            }
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
            List<int> shedule = new List<int>();
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
           
            //  MessageBox.Show(sqlQuery);

            try
            {
                if (comboBox1.Text != string.Empty) {
                    comboBox2.Items.Clear();
                    String sqlQuery = "Select classtime from classroom where staffid =" + Ids[comboBox1.SelectedIndex] + "and classdate='" + dateTimePicker1.Value.ToString("yyyy/MM/dd") + "'";
                    cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        shedule.Add(rdr.GetInt32(0));

                    }
                }
                else
                {
                    MessageBox.Show("No data to read in");

                }
                rdr.Close();
                cnn.Close();
                foreach (var item in conversion)
                {
                    if (!shedule.Contains(item.Key))
                    {
                        comboBox2.Items.Add(item.Value);
                    }
                }
                if (comboBox2.Items.Count==0)//conversion.Count == shedule.Count
                    {
                    MessageBox.Show("No avalible time for "+comboBox1.Text);
                }
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
