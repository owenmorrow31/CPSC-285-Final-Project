﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Assigment11_V1
{
    public partial class Form1 : Form
    {
        Form2 form2;
        Form3 form3;
        public Form1()
        {
            InitializeComponent();
         form2 = new Form2();
            form3 = new Form3();
        }

        private void staffBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.staffBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.assigment11DataSet);
          
            
                
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try { 
            
            this.classroomTableAdapter.Fill(this.assigment11DataSet.Classroom);
            
            this.staffTableAdapter.Fill(this.assigment11DataSet.Staff);
                if (positionTextBox.Text.Trim() == "Instructor")
                {
                    todayradioBtn.Visible = true; weekradiobtn.Visible = true; MonthRadiobtn.Visible = true;
                    weekradiobtn.Checked = true; dataGridView1.Visible = true;
                }
                else
                {
                    todayradioBtn.Visible = false; weekradiobtn.Visible = false; MonthRadiobtn.Visible = false;
                    dataGridView1.Visible=false;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            } 

        }

       

       

        private void staffBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            
            if (positionTextBox.Text.Trim() == "Instructor")
            {
                if (weekradiobtn.Checked)//have this because the data would double up
                {
                    string query = "Select classdate,classtime,client.clientname from classroom join client on classroom.clientid = client.id where classroom.staffid=" + idTextBox.Text + "and classroom.Classdate between '" + DateTime.Now.ToString("yyyy/MM/dd") + "' and '" + DateTime.Now.AddDays(7).ToString("yyyy/MM/dd") + "'";
                    Loaddata(query, dataGridView1);
                }

                todayradioBtn.Visible = true; weekradiobtn.Visible = true; MonthRadiobtn.Visible = true;
                weekradiobtn.Checked = true; dataGridView1.Visible = true;
                
              
            }
            else
            {
                todayradioBtn.Visible = false; weekradiobtn.Visible = false; MonthRadiobtn.Visible = false; dataGridView1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
              form3.ShowDialog();
                if (form3.DialogResult == DialogResult.OK) {
                dataGridView1.Refresh();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        { 
            if (todayradioBtn.Checked) {
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
                string query = "Select classdate,classtime,client.clientname from classroom join client on classroom.clientid = client.id where classroom.staffid=" + idTextBox.Text+"and classroom.Classdate='"+DateTime.Now.ToString("yyyy/MM/dd")+"'";
               // MessageBox.Show(query);
                Loaddata(query,dataGridView1);
            
            }
        }
        public static void Loaddata(string query,DataGridView dataGridView1)
        {
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
            String sqlQuery = query;
            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        var index = dataGridView1.Rows.Add();
                        dataGridView1.Rows[index].Cells[0].Value = rdr[0];
                        dataGridView1.Rows[index].Cells[1].Value = rdr[1];
                        dataGridView1.Rows[index].Cells[2].Value = rdr[2];

                    }
                }
                else
                {
                    MessageBox.Show("No data read in");
                }
                rdr.Close();
                cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void weekradiobtn_CheckedChanged(object sender, EventArgs e)
        {
            if (weekradiobtn.Checked)
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
                string query = "Select classdate,classtime,client.clientname from classroom join client on classroom.clientid = client.id where classroom.staffid=" + idTextBox.Text + "and classroom.Classdate between '" + DateTime.Now.ToString("yyyy/MM/dd") + "' and '"+DateTime.Now.AddDays(7).ToString("yyyy/MM/dd") + "'";
                // MessageBox.Show(query);
                Loaddata(query, dataGridView1);

            }
        }

        private void MonthRadiobtn_CheckedChanged(object sender, EventArgs e)
        {
            if (MonthRadiobtn.Checked)
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
                string query = "Select classdate,classtime,client.clientname from classroom join client on classroom.clientid = client.id where classroom.staffid=" + idTextBox.Text + "and classroom.Classdate between '" + DateTime.Now.ToString("yyyy/MM/dd") + "' and '" + DateTime.Now.AddMonths(1).ToString("yyyy/MM/dd") + "'";
                
                Loaddata(query, dataGridView1);

            }
        }
    }
}
