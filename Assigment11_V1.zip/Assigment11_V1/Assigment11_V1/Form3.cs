﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigment11_V1
{
    
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            string connectionString = "Data Source=BOB_LOP\\NEWSERVER;Initial Catalog=Assigment11;Integrated Security=True";
            SqlConnection cnn;
            SqlCommand cmd;
            SqlDataReader rdr;
            String sqlQuery = "Select Staffname from staff where position ='instructor'";
           
            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                cmd = new SqlCommand(sqlQuery, cnn);
                rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        comboBox1.Items.Add(rdr[0]);
                        
                       

                    }
                }
                else
                {
                    MessageBox.Show("No data read in");
                }
                rdr.Close();
                cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.assigment11DataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'assigment11DataSet.Staff' table. You can move, or remove it, as needed.
            this.staffTableAdapter.Fill(this.assigment11DataSet.Staff);
            // TODO: This line of code loads data into the 'assigment11DataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.assigment11DataSet.Client);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value.DayOfWeek == DayOfWeek.Saturday || dateTimePicker1.Value.DayOfWeek == DayOfWeek.Sunday)
            {
                MessageBox.Show("Weekdays Only Please");

            }
            if (dateTimePicker1.Value < DateTime.Now)
            {
                MessageBox.Show("Please choose a date thats not prior");
            }
        }
    }
}
